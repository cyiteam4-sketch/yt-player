@echo off
title Riddle School Launcher (No Server)
cls

:: Ensures the script runs from the exact folder it is saved in
cd /d "%~dp0"

:menu
cls
echo ==========================================================
echo               RIDDLE SCHOOL GAME LAUNCHER
echo ==========================================================
echo  1. Riddle School 1 (riddleschool)
echo  2. Riddle School 2 (riddleschool2)
echo  3. Riddle School 3 (riddleschool3)
echo  4. Exit
echo ==========================================================
echo.

set /p choice="Select which game folder to open (1-4): "

if "%choice%"=="1" set "GAME_FOLDER=riddleschool" & goto launch
if "%choice%"=="2" set "GAME_FOLDER=riddleschool2" & goto launch
if "%choice%"=="3" set "GAME_FOLDER=riddleschool3" & goto launch
if "%choice%"=="4" exit
goto menu

:launch
echo.
echo ==========================================================
echo  Opening Microsoft Edge with local JavaScript access...
echo ==========================================================
echo.

:: Get the full absolute path of the chosen game folder
set "FULL_PATH=%cd%\%GAME_FOLDER%"

:: Launch Edge with flags that allow local file access (CORS bypass)
:: Note: This opens a dedicated, secure window for your game.
start msedge "%FULL_PATH%\index.html" --allow-file-access-from-files --user-data-dir="%LOCALAPPDATA%\EdgeGameDevProfile"

echo Game launched! You can close this window now.
timeout /t 3 >nul
exit
